<template>
<div class="container">
    <h1>Shopping Cart</h1>
  
     <ul class="cart-list">
      <li class="row border rounded border-dark" v-for="item in cart" :key="item.pId">
        <div class="column">
        <img v-bind:src="item.image" class="thumbnail" alt="">
        </div>
        <div class="column2">
          <!--<p>{{ item.name }}</p>-->
          <p>Price: ${{ item.price }}</p>
          <p>Quantity: {{ item.quantity }}</p>
        </div>
        <div class="column2">
           <b-button size="sm" @click="removeFromCart(item.pId)" class="my-2 my-sm-0"> Remove </b-button>
          </div>
      </li>
    </ul>

    <b-button to="/checkout/" size="lg" class="my-2 my-sm-0">Checkout</b-button>
      
  
                
       
  
    
</div>
</template>

<script>
import axios from 'axios';
export default {
    name: 'shoppingcart',

    data() {
        return {
        cart: []
        }
    }
    ,

    methods: {

    removeFromCart(pid) {
      axios.delete("http://localhost:8090/shoppingCart/delete-By-Id?cId=2&pId="+pid)
       .catch(() => console.log(pid));
    }
  },

    mounted () {
    axios
      .get('http://localhost:8090/shoppingCart/get-products-By-Id?id=2')
      .then(response => (this.cart = response.data))
      .catch(() => console.log('cart.vue'));
  },
    updated(){
    axios
      .get('http://localhost:8090/shoppingCart/get-products-By-Id?id=2')
      .then(response => (this.cart = response.data))
      .catch(() => console.log('cart.vue'));
  }

    
}
</script>

<style  scoped>

cart-list {
  width: 70%;
  @media only screen and (max-width: 832px) {
    width: 100%;
  }
}
.cart-list__item {
  width: 100%;
  height:100%;
  
  margin-bottom: 20%;
}
.column2{
  flex: 10;
  justify-content: space-between;
  margin-left: 2px;
}

.thumbnail {
  max-width: 50px;
 
  margin-left: 2px;
}
container {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  margin-top: 50px;
  display: grid;
  grid-template-rows: auto;
  grid-template-columns: repeat(1, 100%);
}
</style>