<template>
<div class="login">

 <h1>Login</h1>
</div>
</template>

<script>
  
export default {
    name:'login',
    
    
}
</script>

<style lang="stylus" scoped>

</style>


