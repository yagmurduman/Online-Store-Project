<template>

<div class="container">
<b-navbar   fixed="top" variant ="light" toggleable="lg" v-if="!modal">
    <b-navbar-brand to="/"><img src="@/assets/logo_transparent.png"/></b-navbar-brand>

    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

    <b-collapse id="nav-collapse" is-nav>
      <b-navbar-nav>
        <b-nav-item-dropdown text="Books" right>
             <b-dropdown-item to="/maincategorybooks" > All Books</b-dropdown-item>
             <b-dropdown-item to="/signup/">Literature</b-dropdown-item>
         </b-nav-item-dropdown>
        <b-nav-item-dropdown text="Music" right>
             <b-dropdown-item to="/maincategorymusic" > All Music</b-dropdown-item>
             <b-dropdown-item to="/signup/">Pop</b-dropdown-item>
         </b-nav-item-dropdown>
         <b-nav-item-dropdown text="DVD" right>
             <b-dropdown-item to="/maincategorydvd" > All DVD</b-dropdown-item>
             <b-dropdown-item to="/signup/">Horror</b-dropdown-item>
         </b-nav-item-dropdown>
      </b-navbar-nav>

      <!-- Right aligned nav items -->
      <b-navbar-nav class="ml-auto">
        <b-nav-form>
          
          <b-form-input v-model="text" size="sm" class="mr-sm-2" placeholder="Search"></b-form-input>
          <b-button size="sm" class="my-2 my-sm-0" type="submit" to="/SearchResults/" @click="Search()" >Search</b-button>
        </b-nav-form>


        <b-nav-item-dropdown right>
          <!-- Using 'button-content' slot -->
          <template v-slot:button-content>
            <em>User</em>
          </template>
         
          <b-dropdown-item to="/login">Login</b-dropdown-item>
          <b-dropdown-item to="/signup">Sign Up</b-dropdown-item>
        </b-nav-item-dropdown>
        <b-icon style="margin-top:10px;" icon="bag"  @click="modalAction()"></b-icon>
      </b-navbar-nav>
    </b-collapse>
    
  </b-navbar>
  <div class="sidebar" v-if="modal">
                    <div class="sidebar-backdrop" @click="closeSidebarPanel" v-if="isPanelOpen"></div>
                    <transition name="slide">
                        <div v-if="isPanelOpen"
                            class="sidebar-panel">
                            <shoppingcart/>
                            <slot> </slot>
                        </div>
                    </transition>
                
    </div>
  
</div>
</template>

<script>
import router from '../router/index.js'
import shoppingcart from './ShoppingCart.vue'
import axios from 'axios';
export default {
    name: 'Header',

    components: shoppingcart,
    data (){
        return {
                modal:false,
                isPanelOpen: true,
                text:'',
              }
    },

    methods :{

        modalAction(){
            if(this.modal==false){this.modal=true;this.isPanelOpen=true;}
                else{this.modal=false;}
        
        },
         closeSidebarPanel() {
                this.isPanelOpen = false;
                if(this.modal==false){this.modal=true;}
                else{this.modal=false;}
            }
            ,
         Search() {
                console.log(this.text);
                axios.post("http://localhost:8090/search/"+ this.text)
                .then(response=> this.$store.state.searchProducts = response.data)
                .catch(() => console.log("Search logged in error"));
    
            }

       
    },

};
</script>

<style scoped>
    
    .container{

        text-align: center;
        margin-right:10%;
        margin-bottom: 10%;
        background-color:  rgba(211, 113, 74, 0.911);

    }
    
    img{
        width :    100px;
        height : 100px;
        float: left;
        margin-left: 10px;

    }
    

    .slide-enter-active,
    .slide-leave-active
    {
        transition: transform 3s ease;
    }

    .slide-enter,
    .slide-leave-to {
        transform: translateX(-100%);
        transition: all 1 ms ease-in 2s
    }

    .sidebar-backdrop {
        background-color: rgba(255, 255, 255, 0.541);
        width: 100vw;
        height: 100vh;
        position: fixed;
        top: 0;
        right: 0;
        cursor: pointer;
    }

    .sidebar-panel {
        overflow-y: auto;
        background-color:  rgba(211, 113, 74, 0.911);
        position: fixed;
        right: 0;
        top: 0;
        height: 100vh;
        z-index: 999;
        padding: 3rem 20px 2rem 20px;
        width: 400px;
    }
    

    
</style>