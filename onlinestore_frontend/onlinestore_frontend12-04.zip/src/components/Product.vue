<template>
  <div class="container">
    <span class="border">
    <div class="row1">
      <div class="column">
        <img  class="border rounded" v-bind:src="product.image" />
      </div>
      <div class="column2 border">
        <br> <br>
        <div class="row ">
          
          <h1 style="color:#ed6a5a"> {{ product.pName }}</h1>
        </div>
        <br> <br>
        <div class="row">
          <h3 style="color:#ed7768">Description: {{ product.description }}</h3>
        </div>
        <div class="row">
          <h3 style="color:#ed7768" >Price: ${{ product.price }} </h3>
        </div>
        <div class="row2">
         <h7 style="color:#ed7768" >Quantity: </h7>
        <input type="number"  value="1" min="0" ref="quantityinput" max="100" step="1" />
        </div>
        <br> <br>
        <br> <br>
        <div class="row2">
         <b-button size="sm" class="my-2 my-sm-0" @click="addToCart()">Add to Cart</b-button>
        </div>
      </div>
    </div>
    </span>
  </div>
</template>

<script>
import axios from 'axios';

export default {  
  name: 'product',


  data() {
    return {
      product: [],
      quantity:1
    };
  },
  methods: {
    
    refreshquantity(value){
      this.quantity= this.$refs.quantityinput.value;
      console.log(value);
    },
    addToCart() {
      axios.post("http://localhost:8090/shoppingCart/add-To-Cart",{cId:2, pId:this.product.pId,price:this.product.price,image:this.product.image,quantity:this.quantity})
    }
  },

  mounted() {
    axios
      .get('http://localhost:8090/product/get-by-id/?id=' + this.$route.params.id)
      .then(response => (this.product = response.data))
      .catch(() => console.log('product.vue'));
  }
};
</script>

<style scoped>
img {
  width: 50%;
  height: 80%;
}

.column {
  float: left;
  width: 50%;
}

/* Clear floats after the columns */
.row1{
  margin-top: 5%;
}
.row1:after{
  content: '';
  display: table;
  clear: both;
  margin-left: 40%;
  margin-top:10%;
}
.row2:after {
  content: '';
  display: table;
  clear: both;
  margin-left: 40%;
  margin-top:10%;
}



container {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 50px;
  display: grid;
  grid-template-rows: auto;
  grid-template-columns: repeat(1, 100%);
}
</style>
