<template>
    <div id="checkout">
    <h1>Checkout</h1>
    <div class="container">
    <div class="row">
        <div class="col-sm-5 col-md-12 col-md-offset-1">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th class="text-center">Price</th>
                        <th class="text-center">Total</th>
                        <th> </th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="product in products" :key="product.pId" >
                        <td class="col-sm-8 col-md-6" >
                        <div class="media">
                            <a class="thumbnail pull-left"> <router-link :to="{ name: 'product', params: { id: product.pId } }" replace
                             ><img v-bind:src="product.image" class="figure-img img-fluid rounded" />
                            </router-link> </a>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="#">Product Name</a></h4>
                                <h5 class="media-heading"> by <a href="#">Brand name</a></h5>
                                <span>Status: </span><span class="text-success"><strong>In Stock</strong></span>
                            </div>
                        </div></td>
                        <td class="col-sm-1 col-md-1" style="text-align: center">
                        <input type="email" class="form-control" id="exampleInputEmail1" value="3">
                        </td>
                        <td class="col-sm-1 col-md-1 text-center"><strong>$ {{product.price}}</strong></td>
                        <td class="col-sm-1 col-md-1 text-center"><strong>$14.61</strong></td>
                        <td class="col-sm-1 col-md-1">
                        <button type="button" class="btn btn-danger">
                            <span class="glyphicon glyphicon-remove" @click="removeFromCart(product.pId)"></span> Remove
                        </button></td>
                    </tr>
                   
                   
                    <tr>
                        <td>   </td>
                        <td>   </td>
                        <td>   </td>
                        <td><h3>Total</h3></td>
                        <td class="text-right"><h3><strong>$31.53</strong></h3></td>
                    </tr>
                    <tr>
                        <td>   </td>
                        <td>   </td>
                        <td>   </td>
                        <td>
                        <b-button type="button" class="btn">
                            <span class="glyphicon glyphicon-shopping-cart"></span> Continue Shopping
                        </b-button></td>
                        <td>
                        <b-button type="button" class="btn btn-success">
                            Checkout <span class="glyphicon glyphicon-play"></span>
                        </b-button></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
    </div>
    
</template>

<script>

import axios from 'axios';
export default {
    name: "checkout",
    data() {
    return {
      products: [],
    };
  },
    methods: {

    removeFromCart(pid) {
      axios.delete("http://localhost:8090/shoppingCart/delete-By-Id?cId=2&pId="+pid)
       .catch(() => console.log(pid));
    }
    },

   mounted () {
    axios
      .get('http://localhost:8090/shoppingCart/get-products-By-Id?id=2')
      .then(response => (this.products = response.data))
      .catch(() => console.log('checkout.vue'));
  },

  updated(){
    axios
      .get('http://localhost:8090/shoppingCart/get-products-By-Id?id=2')
      .then(response => (this.cart = response.data))
      .catch(() => console.log('cart.vue'));
  }

    
}
</script>
<style scoped>


</style>