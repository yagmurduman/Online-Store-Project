<template>
  <div class="container">
    <router-link to="/" replace
      ><img style="padding-top: 2%;height: 90%;width:90%;float:center;" src="@/assets/bestsellers.jpg"
    /></router-link>

    <h1>New Comers-Books</h1>
    <carousel style="margin-top:30px">
      <slide v-for="product in products" :key="product.id">
        <router-link :to="{ name: 'product', params: { id: product.pId } }" replace><img v-bind:src="product.image"/></router-link>
        <p>
          <b-link :to="{ name: 'product', params: { id: product.pId } }" replace> {{ product.pName }} </b-link>
        </p>
      </slide>
    </carousel>

    <h1>New Comers-Music</h1>
    <carousel style="margin-top:30px">
      <slide v-for="product in products" :key="product.id">
        <router-link :to="{ name: 'product', params: { id: product.pId } }" replace><img v-bind:src="product.image"/></router-link>
        <p>
          <b-link :to="{ name: 'product', params: { id: product.pId } }" replace> {{ product.pName }} </b-link>
        </p>
      </slide>
    </carousel>

    <h1>New Comers-DVD</h1>
    <carousel style="margin-top:30px">
      <slide v-for="product in products" :key="product.id">
        <router-link :to="{ name: 'product', params: { id: product.pId } }" replace><img v-bind:src="product.image"/></router-link>
        <p>
          <b-link :to="{ name: 'product', params: { id: product.pId } }" replace> {{ product.pName }} </b-link>
        </p>
      </slide>
    </carousel>
  </div>
</template>

<script>
import { Carousel, Slide } from 'vue-carousel';
import axios from 'axios';
export default {
  name: 'Homepage',
  data() {
    return { products: [] };
  },
  /*
  computed:{
     products(){
         return this.$store.state.products
         }
   },*/
  components: {
    Carousel,
    Slide
  },
  /*
  methods: {
    imagePath(product) {
      return require(`../assets/${product.images[0]}`);
    }
  },*/

  mounted(){
    axios.get('http://localhost:8090/product/get-all-products')
    .then(response=> this.products=response.data)
    
  }

  
 

};
</script>

<style scoped>
container {
  display: grid;
  grid-template-rows: auto;
  grid-template-columns: repeat(4, 25%);
}
h1 {
  padding-top: 20px;
}
slide {
  height: 100px;
  width: 100px;
}
</style>
