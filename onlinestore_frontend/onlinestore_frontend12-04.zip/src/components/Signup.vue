<template>
<div class="signup">

    <h1>Sign Up</h1>    
    <table class="table">
        <tbody>
            
            
        </tbody>
        
    </table>
    

</div>
</template>

<script>

export default {
   name:'signup'
    
}
</script>

<style lang="stylus" scoped>

</style>


