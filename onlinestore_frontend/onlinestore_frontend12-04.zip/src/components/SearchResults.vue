<template>
  <div class="container">
    
    <h1>Search Results for...</h1>
    <carousel style="margin-top:30px">
      <slide v-for="product in searchProduct" :key="product.id">
        <router-link :to="{ name: 'product', params: { id: product.pId } }" replace><img v-bind:src="product.image"/></router-link>
        <p>
          <b-link :to="{ name: 'product', params: { id: product.pId } }" replace> {{ product.name }} </b-link>
        </p>
      </slide>
    </carousel>
  </div>
</template>

<script>
import { Carousel, Slide } from 'vue-carousel';


export default {
  name: 'SearchResults',

  data() {
    return { products: [], searchProduct: this.$store.getters.searchProduct };
  },
 
  components: {
    Carousel,
    Slide
  },
 

};
</script>

<style scoped>
container {
  display: grid;
  grid-template-rows: auto;
  grid-template-columns: repeat(4, 25%);
}
h1 {
  padding-top: 20px;
}
slide {
  height: 100px;
  width: 100px;
}
</style>