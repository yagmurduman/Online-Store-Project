<template>
  <div class="maindvd">
    <div class="top">
      <h1>DVD</h1>
      <img class="flex-col--2" src="../assets/Films.jpg" alt="" />
    </div>

    <div class="row">
      <figure class="item" v-for="product in products" :key="product.pId">
        <router-link :to="{ name: 'product', params: { id: product.pId } }" replace
          ><img v-bind:src="product.image" class="figure-img img-fluid rounded" />
        </router-link>
        <figcaption class="figure-caption">{{ product.name }}</figcaption>
      </figure>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  name: 'maindvd',

  data() {
    return {
      products: [],
      
    };
  },

 
  mounted(){
    axios.get('http://localhost:8090/product/get-all-products')
    .then(response=> this.products=response.data)
    .catch(() => console.log("Can’t access response. Blocked by browser?"));
    
  }

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
div {
  padding-left: 10%;
  padding-right: 10%;
}

h1 {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  margin-top: 10%;
  padding-left: 10%;
  color: #993c3c;
  position: absolute;
}
img {
  padding-top: 2%;
  height: 50%;
  width: 50%;
  float: right;
}

.item {
  height: 50%;
  width: 50%;
}
.top {
  margin-bottom: 50%;
}
</style>
