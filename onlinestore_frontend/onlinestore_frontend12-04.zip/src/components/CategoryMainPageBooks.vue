<template>
  <div class="mainbooks">
    <div class="top">
      <h1>Books</h1>
      <img class="flex-col--2" src="../assets/library.jpg" alt="" />
    </div>
    
    <div class="row">
      <figure class="item" v-for="product in products" :key="product.pId">
        <router-link :to="{ name: 'product', params: { id: product.pId } }" replace
          ><img v-bind:src="product.image" class="figure-img img-fluid rounded" />
        </router-link>
        <figcaption class="figure-caption">{{ product.name }}</figcaption>
      </figure>
    </div>
  </div>
  <!---
  <div class="container">
 
    <div v-bind:class= "{'products': groupedProducts}" class="row">
        <div class="col-md-10 col-sm-8">
            <figure class="item" v-for="product in products" :key="product.pId">
            <div class="product-grid6">
                <div class="product-image6">
                    <router-link :to="{ name: 'product', params: { id: product.pId } }" replace
                    ><img v-bind:src="product.image" class="figure-img img-fluid rounded" />
                     </router-link>
                </div>
                <div class="product-content">
                    <h3 class="title"><router-link :to="{ name: 'product', params: { id: product.pId } }" replace
                    >{{ product.pName }}</router-link></h3>
                    <div class="price">${{ product.price }}
                        <span>$14.00</span>
                    </div>
                </div>
                <ul class="social">
                    <li><a href="" data-tip="Add to Wishlist"><i class="fa fa-shopping-bag"></i></a></li>
                    <li><a href="" data-tip="Add to Cart"><i class="fa fa-shopping-cart"></i></a></li>
                </ul>
            </div>
          </figure>
        </div>
    </div>
</div>
</div>
-->
</template>

<script>
import axios from 'axios';

export default {
  name: 'mainbooks',

  data() {
    return {
      products: [],
    };
  },
  computed:{
    groupedProducts() {
      return _.chunk(this.products, 4)
    }
  },

  mounted() {
    axios
      .get('http://localhost:8090/product/get-all-products')
      .then(response => (this.products = response.data))
      .catch(() => console.log('Can’t access response. Blocked by browser?'));
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
div {
  padding-left: 10%;
  padding-right: 10%;
}

h1 {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  margin-top: 10%;
  padding-left: 10%;
  color: #993c3c;
  position: absolute;
}
img {
  padding-top: 2%;
  height: 50%;
  width: 50%;
  float: right;
}

.item {
  height: 50%;
  width: 50%;
}
.top {
  margin-bottom: 50%;
}

.product-grid6,.product-grid6 .product-image6{overflow:hidden}
.product-grid6{font-family:'Open Sans',sans-serif;text-align:center;position:relative;transition:all .5s ease 0s}
.product-grid6:hover{box-shadow:0 0 10px rgba(0,0,0,.3)}
.product-grid6 .product-image6 a{display:block}
.product-grid6 .product-image6 img{width:150%;height:100%;transition:all .5s ease 0s}
.product-grid6:hover .product-image6 img{transform:scale(1.1)}
.product-grid6 .product-content{padding:12px 12px 15px;transition:all .5s ease 0s}
.product-grid6:hover .product-content{opacity:0}
.product-grid6 .title{font-size:20px;font-weight:600;text-transform:capitalize;margin:0 0 10px;transition:all .3s ease 0s}
.product-grid6 .title a{color:#000}
.product-grid6 .title a:hover{color:#2e86de}
.product-grid6 .price{font-size:18px;font-weight:600;color:#2e86de}
.product-grid6 .price span{color:#999;font-size:15px;font-weight:400;text-decoration:line-through;margin-left:7px;display:inline-block}
.product-grid6 .social{background-color:#fff;width:100%;padding:0;margin:0;list-style:none;opacity:0;transform:translateX(-50%);position:absolute;bottom:-50%;left:50%;z-index:1;transition:all .5s ease 0s}
.product-grid6:hover .social{opacity:1;bottom:20px}
.product-grid6 .social li{display:inline-block}
.product-grid6 .social li a{color:#909090;font-size:16px;line-height:45px;text-align:center;height:45px;width:45px;margin:0 7px;border:1px solid #909090;border-radius:50px;display:block;position:relative;transition:all .3s ease-in-out}
.product-grid6 .social li a:hover{color:#fff;background-color:#2e86de;width:80px}
.product-grid6 .social li a:after,.product-grid6 .social li a:before{content:attr(data-tip);color:#fff;background-color:#2e86de;font-size:12px;letter-spacing:1px;line-height:20px;padding:1px 5px;border-radius:5px;white-space:nowrap;opacity:0;transform:translateX(-50%);position:absolute;left:50%;top:-30px}
.product-grid6 .social li a:after{content:'';height:15px;width:15px;border-radius:0;transform:translateX(-50%) rotate(45deg);top:-20px;z-index:-1}
.product-grid6 .social li a:hover:after,.product-grid6 .social li a:hover:before{opacity:1}
@media only screen and (max-width:832){.product-grid6{margin-bottom:30px}
}
</style>
