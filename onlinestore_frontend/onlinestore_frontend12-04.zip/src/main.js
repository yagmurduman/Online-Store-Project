import Vue from 'vue'
import App from './App.vue'
import VueCarousel from 'vue-carousel';
import { BootstrapVue, BootstrapVueIcons } from 'bootstrap-vue'
import router from './router/index.js'
import shoppingcart from "./components/ShoppingCart.vue"
import 'bootstrap/dist/css/bootstrap.min.css'
import {store} from './store.js'
import axios from 'axios'
import VueAxios from 'vue-axios'
 

Vue.use(VueAxios, axios)
Vue.use(BootstrapVue)
Vue.use(BootstrapVueIcons)
Vue.use(VueCarousel);

Vue.component('shoppingcart',shoppingcart);

Vue.config.productionTip = false

new Vue({
  store,
  router,
  render: h => h(App),
}).$mount('#app')
