import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex);

export const store = new Vuex.Store({

    state:{
        wishlist:[],
        categories:[{id:1,name:"All Books",images:['library.jpg']},{id:2,name:"All Music",images:['Music.png']},{id:3,name:"All DVDs",images:['Films.jpg']}],
        Search:[],
    },

    getters: {
       

        category: (state) => (id) => {
            return state.categories.filter(p => p.id === Number(id))[0]
        },
        
      },

});
