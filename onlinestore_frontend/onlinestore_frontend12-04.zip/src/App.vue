<template>
  <div id="app">
    <Header />

    <router-view> <Homepage /> </router-view>
  </div>
</template>

<script>
import Homepage from './components/HomePage.vue';
import Header from './components/Header-notloggedin.vue';

export default {
  name: 'App',
  components: {
    Header,
    Homepage
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 10px;
  display: grid;
  grid-template-rows: auto;
  grid-template-columns: repeat(1, 100%);
}
</style>
